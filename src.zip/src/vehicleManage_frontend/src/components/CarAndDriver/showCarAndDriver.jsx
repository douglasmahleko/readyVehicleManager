import React, { useState, useEffect } from "react"; 
import CreateTable from '../constants/createTable'
import BasicCard from '../constants/basicCard';
import SearchBar from "../constants/searchBar";

function ShowCarAndDriver({backendActor}){
    const [stories, setStories] = useState([])
const [storiess, setStoriess] = useState([
    {email:"email",plateNo:"plateNo",destination:"destination",dateAndTime:"dateAndTime",purpose:"purpose",importance:"importance",
        initialOdometerOnStartingJourney:"initialOdometerOnStartingJourney",finalOdometerOnFinishingJourney:"finalOdometerOnFinishingJourney",comments:"comments"},
    {email:"email",plateNo:"plateNo",destination:"destination",dateAndTime:"dateAndTime",purpose:"purpose",importance:"importance",
        initialOdometerOnStartingJourney:"initialOdometerOnStartingJourney",finalOdometerOnFinishingJourney:"finalOdometerOnFinishingJourney",comments:"comments"},
    {email:"email",plateNo:"plateNo",destination:"destination",dateAndTime:"dateAndTime",purpose:"purpose",importance:"importance",
        initialOdometerOnStartingJourney:"initialOdometerOnStartingJourney",finalOdometerOnFinishingJourney:"finalOdometerOnFinishingJourney",comments:"comments"},
    {email:"email",plateNo:"plateNo",destination:"destination",dateAndTime:"dateAndTime",purpose:"purpose",importance:"importance",
        initialOdometerOnStartingJourney:"initialOdometerOnStartingJourney",finalOdometerOnFinishingJourney:"finalOdometerOnFinishingJourney",comments:"comments"},
])
    const tableHeader = [
    {id:'email', name:"Email"},{id:'plateNo', name:"Plate No"},{id:'destination', name:"Destination"},{id:'dateAndTime', name:"Date And Time"},
    {id:'purpose', name:"Purpose"},{id:'importance', name:"Importance"},{id:'initialOdometerOnStartingJourney', name:"Initial Odometer On Starting Journey"},
    {id:'finalOdometerOnFinishingJourney', name:"Final Odometer On Finishing Journey"},{id:'comments', name:"Comments"}
]
    const [search, setSearch] = useState("")
    const [getting, setGetting] = useState(false);
    useEffect(() => {
        getCars();
      }, []);
    const getCars = async () => {
        try {
          const messages = await backendActor.searchCarAndDriverData();
          setStories(messages);
          console.log( "the messages " + messages)
          console.log( "the stories " + stories)
          
        } catch (error) {
          console.log("Error on getting topics ", error);
        }
      }; 
      const sendMessage = async (e) => {
        const [newStories, setNewStories] = useState([])
        e.preventDefault();
        try {
          setGetting(true);
          const messages0 = await backendActor.searchCarAndDriverData(search);
          // setSearch("");
          setNewStories(messages0)
          console.log("data ", newStories);
          console.log("data ", messages0);
          setGetting(true);
        } catch (error) {
          console.log("Error on send title ", error);
          setGetting(false);
        }
        if(newStories){
          setStories(newStories)
        }
        else{
          console.log("new stories arenewStories.length ", newStories.length)
        }
      };
    return(
        <BasicCard content={<CreateTable data={stories} tableHeader={tableHeader} />}
         header={ <SearchBar onClick={sendMessage} searchValue={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search for cars and their drivers" title="Our Cars and The Driver history" getting={getting} /> } />
    )
}
export default ShowCarAndDriver