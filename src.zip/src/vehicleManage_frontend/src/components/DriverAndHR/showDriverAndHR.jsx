import React, { useState, useEffect } from "react";
import CreateTable from '../constants/createTable'
import BasicCard from '../constants/basicCard';
import SearchBar from "../constants/searchBar";

function ShowDriverAndHR({backendActor}){
    const [stories, setStories] = useState([])
    const [storiess, setStoriess] = useState([
      {hr:"hr", punishment:"punishment", driver:"driver", offense:"offense",judgement:"judgement"},
      {hr:"hr", punishment:"punishment", driver:"driver", offense:"offense",judgement:"judgement"},
      {hr:"hr", punishment:"punishment", driver:"driver", offense:"offense",judgement:"judgement"},
  ])
    const [search, setSearch] = useState("")
    const [getting, setGetting] = useState(true);
    const tableHeader = [
        {id:"hr" , name:"HR"}, {id:"punishment" , name:"Punishment"}, {id:"driver" , name:"Driver"}, 
        {id:"offense" , name:"Offense"},{id:"judgement" , name:"Judgement"}
    ]
    
    useEffect(() => {
        getCars();
      }, []);

    const getCars = async () => {
        try {
          const messages = await backendActor.getDriversAndHRData();
          setStories(messages);
          setGetting(true)
        } catch (error) {
          console.log("Error on getting topics ", error);
          setGetting(false)
        }
      };
      const sendMessage = async (e) => {
        const [newStories, setNewStories] = useState([])
        e.preventDefault();
        try {
          setGetting(true);
          console.log("search ", search);
          const messages0 = await backendActor.searchDriverAnHrData(search);
          // setSearch("");
          setNewStories(messages0)
          console.log("data ", newStories);
          console.log("data ", messages0);
          setGetting(true);
        } catch (error) {
          console.log("Error on send title ", error);
          setGetting(false);
        }
        if(newStories){
          setStories(newStories)
        }
        else{
          console.log("new stories arenewStories.length ", newStories.length)
        }
      };
    return(
        <BasicCard content={<CreateTable data={stories} tableHeader={tableHeader} />}
         header={ <SearchBar onClick={sendMessage}  searchValue={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search for complaints" title="HR hearings" getting={getting} /> } />
    )
}
export default ShowDriverAndHR