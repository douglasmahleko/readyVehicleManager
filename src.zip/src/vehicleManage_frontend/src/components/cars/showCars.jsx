import React, { useState, useEffect } from "react";
import CreateTable from '../constants/createTable'
import BasicCard from '../constants/basicCard';
import SearchBar from "../constants/searchBar";
import { Typography } from "@mui/material";

function ShowCars({backendActor}){
    const [visible, setVisible] = useState(false)
    const [stories, setStories] = useState([])
    const [stories1, setStories1] = useState([])
    const [stories2, setStories2] = useState([])
  const [storiess, setStoriess] = useState([
    {engineNo:"engineNo", plateNo:"plateNo", dateCarBought:"dateCarBought",mileageToDoService:"mileageToDoService", addedBy:"addedBy", statusOfCar:"statusOfCar",
  audometerOnBuying:"audometerOnBuying", carName:"carName", carType:"carType",department:"department"},
  {engineNo:"engineNo", plateNo:"plateNo", dateCarBought:"dateCarBought",mileageToDoService:"mileageToDoService", addedBy:"addedBy", statusOfCar:"statusOfCar",
  audometerOnBuying:"audometerOnBuying", carName:"carName", carType:"carType",department:"department"},
  {engineNo:"engineNo", plateNo:"plateNo", dateCarBought:"dateCarBought",mileageToDoService:"mileageToDoService", addedBy:"addedBy", statusOfCar:"statusOfCar",
  audometerOnBuying:"audometerOnBuying", carName:"carName", carType:"carType",department:"department"},
])

    const tableHeader = [
      { id: 'engineNo', name : 'Engine No' },
      { id: 'plateNo', name : 'Plate No' },
      { id: 'dateCarBought', name : 'Date Car Bought' },
      { id: 'mileageToDoService', name : 'Mileage To DoService' },
      { id: 'addedBy', name : 'Added By' },
      { id: 'statusOfCar', name : 'Status OfCar' },
      { id: 'audometerOnBuying', name : 'Audometer On Buying'},
      { id: 'carName', name : 'Car Name' },
      { id: 'carType', name : 'Car Type' },
      { id: 'department', name : 'Department' },
  ]

    const [search, setSearch] = useState("")
    const [getting, setGetting] = useState(false);
    
    useEffect(() => {
        getCars();
        console.log(stories)
      }, []);

    const getCars = async () => {
        try {
          const messages = await backendActor.getCarsData();
          setStories(messages);
          setStories1([messages]);
          console.log( "the messages " + messages[0])
          console.log( "the messages " + messages[0].engineNo)
          console.log( "the messages " + messages)
          console.log( "the messages " + [messages])
          console.log( "the stories " + stories)
          console.log( "the stories 1" + stories1)
          setGetting(true)
        } catch (error) {
          console.log("Error on getting topics ", error);
          setGetting(false)
        }
      };
    const sendMessage = async (e) => {
        const [newStories, setNewStories] = useState([])
        e.preventDefault();
        try {
          setGetting(true);
          console.log("search ", search);
          const messages0 = await backendActor.searchCarData(search);
          // setSearch("");
          setNewStories(messages0)
          console.log("data ", newStories);
          console.log("data ", messages0);
          setGetting(true);
        } catch (error) {
          console.log("Error on send title ", error);
          setGetting(false);
        }
        if(newStories){
          setStories(newStories)
        }
        else{
          console.log("new stories arenewStories.length ", newStories.length)
        }
      };

    return(
        <BasicCard content={<CreateTable data={stories} tableHeader={tableHeader} />}
         header={ <SearchBar searchValue={search} 
         onClick={sendMessage}
         onChange={(e) => setSearch(e.target.value)} 
         placeholder="Search for cars" title="Our Cars" 
         getting={getting} /> } />
    )
}
export default ShowCars