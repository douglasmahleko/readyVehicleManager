import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.scss';

import { vehicleManage_backend } from 'declarations/vehicleManage_backend';
import { Box } from '@mui/material';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ShowCarsAndAccountas from './components/CarAndAccounts/showCarsAndAccountas';
import AddCarAndAccounts from './components/CarAndAccounts/addCarAndAccounts';
import ShowCars from './components/cars/showCars';
import AddCar from './components/cars/addCar';
import ShowDriverAndAccounts from "./components/DriverAndAccountant/showDriverAndAccounts"
import ShowEmpsAndCar from "./components/empsAndCars/showEmpsAndCar"
import ShowCarAndDriver from "./components/CarAndDriver/showCarAndDriver"
import ShowDriverAndHR from "./components/DriverAndHR/showDriverAndHR"
import ShowUsers from "./components/users/showUsers"
import AddEmpsAndCars from "./components/empsAndCars/addEmpsAndCar"
import AddDriverAndHR from "./components/DriverAndHR/addDriversAndHR"
import AddCarAndDriver from "./components/CarAndDriver/addcarAndDriver"
import AddDriverAndAccountant from "./components/DriverAndAccountant/addDriverAndAccountant"
import AddUser from "./components/users/addUser"

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
            <App backendActor={vehicleManage_backend} >
              <Box>
                <Routes>
                <Route path="/addCar" element = {<AddCar backendActor={vehicleManage_backend} />}  />
                <Route path="/addCarAndAccounts" element = {<AddCarAndAccounts backendActor={vehicleManage_backend} />} />
                <Route path="/showCars" element = {<ShowCars backendActor={vehicleManage_backend} />} />
                <Route path="/showCarsAndAccountas" element = {<ShowCarsAndAccountas backendActor={vehicleManage_backend} />} />
                <Route path="/addDriverAndAccountant" element = {<AddDriverAndAccountant backendActor={vehicleManage_backend} />} />
                <Route path="/addUser" element = {<AddUser backendActor={vehicleManage_backend} />} />
                <Route path="/addCarAndDriver" element = {<AddCarAndDriver backendActor={vehicleManage_backend} />} />
                <Route path="/addEmpsAndCars" element = {<AddEmpsAndCars backendActor={vehicleManage_backend} />} />
                <Route path="/addDriverAndHR" element = {<AddDriverAndHR backendActor={vehicleManage_backend} />} />
                <Route path="/showDriverAndAccounts" element = {<ShowDriverAndAccounts />} />
                <Route path="/showEmpsAndCar" element = {<ShowEmpsAndCar backendActor={vehicleManage_backend} />} />
                <Route path="/showCarAndDriver" element = {<ShowCarAndDriver backendActor={vehicleManage_backend} />} />
                <Route path="/showDriverAndHR" element = {<ShowDriverAndHR backendActor={vehicleManage_backend} />} /> 
                <Route path="/showUsers" element = {<ShowUsers backendActor={vehicleManage_backend} />} /> 
                </Routes>
              </Box>
            </App>
          </BrowserRouter>
  </React.StrictMode>,
);
