
import  React, { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from "./components/home"
import AddCar from "./components/cars/addCar"
import AddCarAndAccounts from "./components/CarAndAccounts/addCarAndAccounts"
import AddDriverAndAccountant from "./components/DriverAndAccountant/addDriverAndAccountant"
import AddUser from "./components/users/addUser"
import ShowCars from "./components/cars/showCars"
import ShowUsers from "./components/users/showUsers"
import AddEmpsAndCars from "./components/empsAndCars/addEmpsAndCar"
import AddDriverAndHR from "./components/DriverAndHR/addDriversAndHR"
import AddCarAndDriver from "./components/CarAndDriver/addcarAndDriver"
import ShowCarsAndAccountas from "./components/CarAndAccounts/showCarsAndAccountas"
import ShowDriverAndAccounts from "./components/DriverAndAccountant/showDriverAndAccounts"
import ShowEmpsAndCar from "./components/empsAndCars/showEmpsAndCar"
import ShowCarAndDriver from "./components/CarAndDriver/showCarAndDriver"
import ShowDriverAndHR from "./components/DriverAndHR/showDriverAndHR"
import Box from '@mui/material/Box';
import NavBar from './components/navBar/navaBar';
import SideBar from './components/navBar/sideBar';
import Grid from '@mui/material/Grid';
import { useLocation } from 'react-router-dom';

const App = ({children, backendActor}) => {
  console.log(backendActor)
  return(
    <Grid container>
      <Box item >
        <NavBar backendActor={backendActor} />
        <SideBar backendActor={backendActor} />
      </Box>
      <Box sx={{marginLeft:"20%"}}>
        <div >
          {children}
        </div>
      </Box>
    </Grid>
  )
};

export default App;
