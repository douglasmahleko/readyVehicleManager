import type { Principal } from '@dfinity/principal';
import type { ActorMethod } from '@dfinity/agent';
import type { IDL } from '@dfinity/candid';

export interface CarAndDriver {
  'destination' : string,
  'initialOdometerOnStartingJourney' : number,
  'email' : string,
  'plateNo' : string,
  'finalOdometerOnFinishingJourney' : number,
  'dateAndTime' : string,
  'comments' : string,
  'purpose' : string,
}
export interface Cars {
  'engineNo' : string,
  'dateCarBought' : string,
  'mileageToDoService' : number,
  'plateNo' : string,
  'addedBy' : string,
  'statusOfCar' : string,
  'audometerOnBuying' : number,
  'carName' : string,
  'carType' : string,
  'department' : string,
}
export interface CarsAndFuel {
  'fuelCardType' : string,
  'fuelCardPaymentDay' : string,
  'email' : string,
  'plateNo' : string,
  'fuelCardAmount' : number,
}
export interface CarsAndInsurance {
  'amountPaidOfRadioInsur' : number,
  'datePaidRadioInsur' : string,
  'datePaidCarInsur' : string,
  'expiryDateOfInsur' : string,
  'email' : string,
  'plateNo' : string,
  'expiryDateOfRadioInsur' : string,
  'amountPaidOfInsur' : bigint,
}
export interface CarsAndService {
  'dateOfService' : string,
  'costOfService' : number,
  'email' : string,
  'servicedAt' : string,
  'plateNo' : string,
}
export interface CarsAndZinara {
  'zinarPaymentsAmount' : number,
  'zinaraPaymentDate' : string,
  'zinaraExpiryDate' : string,
  'email' : string,
  'plateNo' : string,
}
export interface Driver {
  'ratings' : number,
  'email' : string,
  'level' : string,
  'experience' : string,
  'licenseNo' : string,
  'classLicense' : bigint,
}
export interface DriverAndAccountants {
  'accountant' : string,
  'signedBy' : string,
  'purposeOfMoney' : string,
  'amountGiven' : number,
  'driver' : string,
}
export interface DriverAndHR {
  'hr' : string,
  'punishment' : string,
  'judgement' : string,
  'offense' : number,
  'driver' : string,
}
export interface EmpsAndCar {
  'supervisor' : string,
  'status' : string,
  'tasks' : string,
  'importance' : string,
  'employee' : string,
}
export interface User {
  'dob' : string,
  'sex' : string,
  'title' : string,
  'contact' : bigint,
  'userHistory' : string,
  'duty' : string,
  'idNo' : string,
  'name' : string,
  'surname' : string,
  'email' : string,
  'addedBy' : string,
  'address' : string,
}
export interface _SERVICE {
  'addCar' : ActorMethod<[Cars], undefined>,
  'addCarAndDriver' : ActorMethod<[CarAndDriver], undefined>,
  'addCarAndFuel' : ActorMethod<[CarsAndFuel], undefined>,
  'addCarAndService' : ActorMethod<[CarsAndService], undefined>,
  'addCarAndZanara' : ActorMethod<[CarsAndZinara], undefined>,
  'addCarsAndInsurance' : ActorMethod<[CarsAndInsurance], undefined>,
  'addDriver' : ActorMethod<[Driver], undefined>,
  'addDriverAndAccountant' : ActorMethod<[DriverAndAccountants], undefined>,
  'addDriverAndHr' : ActorMethod<[DriverAndHR], undefined>,
  'addEmpAndCar' : ActorMethod<[EmpsAndCar], undefined>,
  'addUser' : ActorMethod<[User], undefined>,
  'getCarsAndDriversData' : ActorMethod<[], Array<CarAndDriver>>,
  'getCarsAndFuelData' : ActorMethod<[], Array<CarsAndFuel>>,
  'getCarsAndInsuranceData' : ActorMethod<[], Array<CarsAndInsurance>>,
  'getCarsAndServiceData' : ActorMethod<[], Array<CarsAndService>>,
  'getCarsAndZinaraData' : ActorMethod<[], Array<CarsAndZinara>>,
  'getCarsData' : ActorMethod<[], Array<Cars>>,
  'getDriversAndAccountantsData' : ActorMethod<[], Array<DriverAndAccountants>>,
  'getDriversAndHRData' : ActorMethod<[], Array<DriverAndHR>>,
  'getDriversData' : ActorMethod<[], Array<Driver>>,
  'getEmpsAndDriversData' : ActorMethod<[], Array<EmpsAndCar>>,
  'getUsersData' : ActorMethod<[], Array<User>>,
  'searchCarAndDriverData' : ActorMethod<[string], Array<CarAndDriver>>,
  'searchCarAndFuelData' : ActorMethod<[string], Array<CarsAndFuel>>,
  'searchCarAndInsuranceData' : ActorMethod<[string], Array<CarsAndInsurance>>,
  'searchCarAndServiceData' : ActorMethod<[string], Array<CarsAndService>>,
  'searchCarAndZinaraData' : ActorMethod<[string], Array<CarsAndZinara>>,
  'searchCarData' : ActorMethod<[string], Array<Cars>>,
  'searchDriverAnHrData' : ActorMethod<[string], Array<DriverAndHR>>,
  'searchDriverAndAccountantData' : ActorMethod<
    [string],
    Array<DriverAndAccountants>
  >,
  'searchDriverData' : ActorMethod<[string], Array<Driver>>,
  'searchEmpAndCarData' : ActorMethod<[string], Array<EmpsAndCar>>,
  'searchUsersData' : ActorMethod<[string], Array<User>>,
}
export declare const idlFactory: IDL.InterfaceFactory;
export declare const init: ({ IDL }: { IDL: IDL }) => IDL.Type[];
